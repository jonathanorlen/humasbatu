<aside class="main-sidebar" style="background:#20873e;">
	<section class="sidebar">  
		<ul class="sidebar-menu">
			<li class="active">
				<a href="<?php echo base_url('admin'); ?>">
					<i class="fa fa-dashboard"></i> <span>Dashboard</span>
				</a>              
			</li>   

			<li class="treeview">
				<a href="<?php echo base_url() . 'admin/slider/daftar'?>">
					<i class="fa fa-photo"></i>
					<span>Slider</span>      

				</a>
			</li>

			<li class="treeview">
				<a href="#">
					<i class="fa fa-edit"></i>
					<span>Profile</span>      
					<i class="fa fa-angle-left pull-right"></i> 
				</a>
				<ul class="treeview-menu">
					<li><a href="<?php echo base_url().'admin/sejarah_kota/daftar';?>"><i class="fa fa-circle-o"></i>Sejarah Kota Batu</a></li>
					<li><a href="<?php echo base_url().'admin/visi_pemkot/daftar';?>"><i class="fa fa-circle-o"></i>Visi Misi Pemerintah</a></li>
					<li><a href="<?php echo base_url().'admin/struktur_pemkot/daftar';?>"><i class="fa fa-circle-o"></i>Struktur Organisasi Pemerintah</a></li>
					<li><a href="<?php echo base_url().'admin/visi_humas/daftar';?>"><i class="fa fa-circle-o"></i>Visi Misi Humas</a></li>
					<li><a href="<?php echo base_url().'admin/struktur_humas/daftar';?>"><i class="fa fa-circle-o"></i>Struktur Organisasi Humas</a></li>
				</ul> 
			</li>

			<li class="treeview">
				<a href="<?php echo base_url() . 'admin/kategori_artikel/daftar'?>">
					<i class="fa fa-user"></i>
					<span>Kategori Artikel</span>      

				</a>
			</li>


			<li class="treeview">
				<a href="<?php echo base_url() . 'admin/artikel/daftar' ?>">
					<i class="fa fa-edit"></i>
					<span>Artikel</span>      

				</a>

				<li class="treeview">
					<a href="<?php echo base_url(). 'admin/agenda/daftar'?>">
						<i class="fa fa-edit"></i>
						<span>Agenda</span>      

					</a>
       <!--  <ul class="treeview-menu">
          <li><a href="<?php echo base_url() . 'admin/product/tambah' ?>"><i class="fa fa-circle-o"></i>Tambah</a></li>
          <li><a href="<?php echo base_url() . 'admin/product/daftar' ?>"><i class="fa fa-circle-o"></i>Daftar</a></li>
      </ul> -->
  </li>

  <li class="treeview">
  	<a href="#">
  		<i class="fa fa-files-o"></i>
  		<span>Sambutan</span>      
  		<i class="fa fa-angle-left pull-right"></i>          
  	</a>
  	<ul class="treeview-menu">
  		<li><a href="<?php echo base_url() . 'admin/sambutan_walikota/daftar' ?>"><i class="fa fa-circle-o"></i>Sambutan Walikota</a></li>
  		<li><a href="<?php echo base_url() . 'admin/sambutan_humas/daftar' ?>"><i class="fa fa-circle-o"></i>Sambutan Kabag Humas</a></li>
  		<li><a href="<?php echo base_url() . 'admin/sambutan_pers/daftar' ?>"><i class="fa fa-circle-o"></i>Pers Release</a></li>
  	</ul>
  </li>

  <li class="treeview">
  	<a href="<?php echo base_url() . 'admin/testimonial/daftar' ?>">
  		<i class="fa fa-edit"></i>
  		<span>Testimonial</span>      

  	</a>

  </li>
  <li class="treeview">
  	<a href="<?php echo base_url() . 'admin/galeri/daftar' ?>">
  		<i class="fa fa-image"></i>
  		<span>Gallery</span>                              
  	</a>                   
  </li>

  <li class="treeview">
  	<a href="<?php echo base_url() . 'admin/Komentar_artikel/daftar' ?>">
  		<i class="fa fa-edit"></i>
  		<span>Komentar Artikel</span>      

  	</a>

  </li>

  <li class="treeview">
  	<a href="<?php echo base_url() . 'admin/download/daftar' ?>">
  		<i class="fa fa-download"></i>
  		<span>Download</span>      

  	</a>

  </li>

    <li class="treeview">
  	<a href="<?php echo base_url() . 'admin/video/daftar' ?>">
  		<i class="fa fa-image"></i>
  		<span>Video</span>      

  	</a>

  </li>

  <li class="treeview">
          <a href="<?php echo base_url() . 'admin/widget/daftar' ?>">
            <i class="fa fa-edit"></i>
            <span>Widget</span>      

          </a>
  </li>

</ul>
</section>
<!-- /.sidebar -->
</aside> -->




