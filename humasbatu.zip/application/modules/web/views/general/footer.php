<div class="clearfix"></div>
<div class="footer text-center" style="background:#eee; max-width: 100%;">
	<div class="bottom-menu">
		<ul>                 
			<li><a href="<?php echo base_url(). 'web/beranda/'?>">Beranda</a></li>|
			<li><a href="<?php echo base_url(). 'web/sejarah_batu/'?>">Profil</a></li>|
			<li><a href="<?php echo base_url(). 'web/informasi/008/'?>">Informasi</a></li>|
			<li><a href="<?php echo base_url(). 'web/agenda/'?>">Agenda</a></li>|
			<li><a href="<?php echo base_url(). 'web/sambutan/walikota/'?>">Sambutan</a></li>|
			<li><a href="<?php echo base_url(). 'web/berita/'?>">Berita</a></li>|
			<li><a href="<?php echo base_url(). 'web/buletin/'?>">Buletin</a></li>|
			<li><a href="<?php echo base_url(). 'web/galeri/'?>">Gallery</a></li>|
			<li><a href="<?php echo base_url(). 'web/testimonial/'?>">Testimonial</a></li>|
			<li><a href="<?php echo base_url(). 'web/kontak/'?>">Hubungi kami</a></li>				
		</ul>
	</div>
	<div class="copyright text-center">
		<p>HUMAS BATU &copy; 2017 All rights reserved | Template by  <a href="http://cloud-astro.com">Cloud Astro</a></p>
	</div>
</div>
</div>
</div>
</body>
</html>