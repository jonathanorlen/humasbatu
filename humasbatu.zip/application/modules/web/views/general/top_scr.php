<!DOCTYPE html>
<html>
<head>
	<title>Humas Batu</title>
	<link href="<?php echo base_url() . 'component/web/css/bootstrap.css'?>" rel="stylesheet" type="text/css"/>
	<!-- Custom Theme files -->
	<link href="<?php echo base_url() . 'component/web/css/style.css'?>" rel="stylesheet" type="text/css"  />
	<link href="<?php echo base_url() . 'component/web/css/flexslider.css'?>" rel="stylesheet" type="text/css"  />
	<link href="<?php echo base_url() . 'component/web/css/popuo-box.css'?>" rel="stylesheet" type="text/css"  />
	<!-- Custom Theme files -->
	<script type="text/javascript" src="<?php echo base_url() . 'component/web/js/jquery.min.js'?>"></script>
	<script type="text/javascript" src="<?php echo base_url() . 'component/web/js/jquery.flexslider.min.js'?>"></script>
	<script type="text/javascript" src="<?php echo base_url() . 'component/web/js/jquery.flexisel.min.js'?>"></script>
	<script type="text/javascript" src="<?php echo base_url() . 'component/web/js/jquery.leanModal.min.js'?>"></script>
	<script type="text/javascript" src="<?php echo base_url() . 'component/web/js/jquery.magnific-popup.min.js'?>"></script>
	<script type="text/javascript" src="<?php echo base_url() . 'component/web/js/responsiveslides.min.js'?>"></script>
	<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" />
	<!-- Custom Theme files -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="The News Reporter Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
	Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!--webfont-->

</head>
<style>
	html,body { 
		background: url('<?php echo base_url().'component/web/images/11212.jpg' ?>') no-repeat center center fixed !important; 
		-webkit-background-size: cover !important;
		-moz-background-size: cover !important;
		-o-background-size: cover !important;
		background-size: cover !important;
	}
</style>
<body>
	<!-- header-section-starts -->
	<div class="container">	
	<div class="news-paper" style="background-color: #333; margin-bottom: -55px; width: 100%; height: 45px;border-bottom: 5px solid #448D00;z-index: 99999999999999;margin-top: 40px;">
		<a href="https://www.instagram.com/humas_pemkotbatu/" target ="_blank" title="instagram">
		<img style="position: relative;float: right;width: 20px;height: auto;margin-right: 5px;" src="<?php echo base_url(). 'component/web/images/icon6.1.png'?>">
		</a>
		<a href="http://majalahpanderman.blogspot.co.id/" target="_blank" title="majalah panderman">
		<img style="position: relative;float: right;width: 20px;height: auto;margin-right: 5px;" src="<?php echo base_url(). 'component/web/images/icon5.1.png'?>">
		</a>
		<a href="http://facebook.com/humasbatu/" target="_blank" title="http://facebook.com/humasbatu/">
		<img hidden width="20px" src="<?php echo base_url(). 'component/web/images/icon6.1.png'?>">
		</a>
		<a href="https://www.youtube.com/c/humaspemerintahkotabatu" target="_blank" title="youtube">
		<img style="position: relative;float: right;width: 20px;height: auto;margin-right: 5px;" src="<?php echo base_url(). 'component/web/images/icon4.png'?>">
		</a>
		<a href="https://www.flickr.com/photos/humaskotabatu" target="_blank" title="flickr">
		<img style="position: relative;float: right;width: 20px;height: auto;margin-right: 5px;" src="<?php echo base_url(). 'component/web/images/icon3.1.png'?>">
		</a>
		<a href="https://twitter.com/Humaskotabatu" target="_blank" title="twitter">
		<img style="position: relative;float: right;width: 20px;height: auto;margin-right: 5px;" src="<?php echo base_url(). 'component/web/images/icon2.1.png'?>">
		</a>
		<a href="https://www.facebook.com/humas.kotabatu/" target="_blank" title="facebook">
		<img style="position: relative;float: right;width: 20px;height: auto;margin-right: 5px;" width="20px" src="<?php echo base_url(). 'component/web/images/icon1.1.png'?>" >
		</a>
	</div>
		<div class="news-paper">
			<!-- <div class="social-icons">
				<li><a href="#"><i class="twitter"></i></a></li>
				<li><a href="#"><i class="facebook"></i></a></li>
				<li><a href="#"><i class="rss"></i></a></li>
			</div> -->
			<div class="header">
				
				<div class="header-left">
					<div class="logo">
						<a href="<?php echo base_url(). 'web/beranda'?>">
							<img src="<?php echo base_url(). 'component/web/images/humas.png'?>" width="200">
						</a>
					</div>
				</div>
				
				<!-- <div class="social-icons">
					<li><a href="https://twitter.com/Humaskotabatu" target="_blank"><i class="twitter"></i></a></li>
					<li><a href="https://www.facebook.com/humas.kotabatu/" target="_blank"><i class="facebook"></i></a></li>
					<li><div class="facebook"><div id="fb-root"></div>

						<div id="fb-root"></div>
					</div></li>
					<script type="text/javascript">
						(function(d, s, id) {
							var js, fjs = d.getElementsByTagName(s)[0];
							if (d.getElementById(id)) return;
							js = d.createElement(s); js.id = id;
							js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.0";
							fjs.parentNode.insertBefore(js, fjs);
						}(document, 'script', 'facebook-jssdk'));
					</script>

					<div class="fb-like" data-href="https://www.facebook.com/humas.kotabatu/" data-layout="button_count" data-action="like" data-show-faces="true" data-share="false"></div>


				</div> -->
				<div class="clearfix"></div>
				<div class="header-right">
					<div class="logo" style="float:right;margin-top:-53px">
						<a href="<?php echo base_url(). 'web/beranda'?>" style="float:right">
							<img src="<?php echo base_url(). 'component/web/images/banner-top-trans.png'?>" width="200">
						</a>
					</div>

					<!-- <div class="top-menu"> -->
						<!-- <ul>        
							<li><a href="index.html">Home</a></li> |  
							<li><a href="about.html">About Us</a></li> |   
							<li><a href="contact.html">Contact Us</a></li>  |   
							<li><a id="modal_trigger" href="#modal" class="btn1">Login</a>

								<div id="modal" class="popupContainer" style="display:none;">
									<header class="popupHeader">
										<span class="header_title">Login</span>
										<span class="modal_close"><i class="fa fa-times"></i></span>
									</header>

									<section class="popupBody">
										
										<div class="social_login">
											<div class="">
												<a href="#" class="social_box fb">
													<span class="icon"><i class="fa fa-facebook"></i></span>
													<span class="icon_title">Connect with Facebook</span>

												</a>

												<a href="#" class="social_box google">
													<span class="icon"><i class="fa fa-google-plus"></i></span>
													<span class="icon_title">Connect with Google</span>
												</a>
											</div>

											<div class="centeredText">
												<span>Or use your Email address</span>
											</div>

											<div class="action_btns">
												<div class="one_half"><a href="#" id="login_form" class="btn">Login</a></div>
												<div class="one_half last"><a href="#" id="register_form" class="btn">Sign up</a></div>
											</div>
										</div>

										
										<div class="user_login">
											<form>
												<label>Email / Username</label>
												<input type="text" />
												<br />

												<label>Password</label>
												<input type="password" />
												<br />

												<div class="checkbox">
													<input id="remember" type="checkbox" />
													<label for="remember">Remember me on this computer</label>
												</div>

												<div class="action_btns">
													<div class="one_half"><a href="#" class="btn back_btn"><i class="fa fa-angle-double-left"></i> Back</a></div>
													<div class="one_half last"><a href="#" class="btn btn_red">Login</a></div>
												</div>
											</form>

											<a href="#" class="forgot_password">Forgot password?</a>
										</div>

										
										<div class="user_register">
											<form>
												<label>Full Name</label>
												<input type="text" />
												<br />

												<label>Email Address</label>
												<input type="email" />
												<br />

												<label>Password</label>
												<input type="password" />
												<br />

												<div class="checkbox">
													<input id="send_updates" type="checkbox" />
													<label for="send_updates">Send me occasional email updates</label>
												</div>

												<div class="action_btns">
													<div class="one_half"><a href="#" class="btn back_btn"><i class="fa fa-angle-double-left"></i> Back</a></div>
													<div class="one_half last"><a href="#" class="btn btn_red">Register</a></div>
												</div>
											</form>
										</div>
									</section>
								</div>

								<script type="text/javascript">
									$("#modal_trigger").leanModal({top : 200, overlay : 0.6, closeButton: ".modal_close" });

									$(function(){
		// Calling Login Form
		$("#login_form").click(function(){
			$(".social_login").hide();
			$(".user_login").show();
			return false;
		});

		// Calling Register Form
		$("#register_form").click(function(){
			$(".social_login").hide();
			$(".user_register").show();
			$(".header_title").text('Register');
			return false;
		});

		// Going back to Social Forms
		$(".back_btn").click(function(){
			$(".user_login").hide();
			$(".user_register").hide();
			$(".social_login").show();
			$(".header_title").text('Login');
			return false;
		});

	})
</script></li> |   
<li><a class="play-icon popup-with-zoom-anim" href="#small-dialog1">Subscribe</a></li>
</ul> -->
<!-- </div> -->
<!---pop-up-box---->  
<link href="<?php echo base_url() . 'component/web/css/popuo-box.css'?>" rel="stylesheet" type="text/css'?>" media="all"/>
<!-- <script src="<?php echo base_url() . 'component/web/js/jquery.magnific-popup.js'?>" type="text/javascript"></script>
 --><!---//pop-up-box---->
<!-- <div id="small-dialog1" class="mfp-hide">
	<div class="signup">
		<h3>Subscribe</h3>
		<h4>Enter Your Valid E-mail</h4>
		<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" />
		<div class="clearfix"></div>
		<input type="submit"  value="Subscribe Now"/>
	</div>
</div> -->	

<script>
	$(document).ready(function() {
		$('.popup-with-zoom-anim').magnificPopup({
			type: 'inline',
			fixedContentPos: false,
			fixedBgPos: true,
			overflowY: 'auto',
			closeBtnInside: true,
			preloader: false,
			midClick: true,
			removalDelay: 300,
			mainClass: 'my-mfp-zoom-in'
		});

	});
</script>	
<!-- <div class="search">
	<form>
		<input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}"/>
		<input type="submit" value="">
	</form>
</div> -->
<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
</div>