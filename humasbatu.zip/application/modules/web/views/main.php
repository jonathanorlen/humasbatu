<script type="text/javascript" src="<?php echo base_url(). 'component/web/js/jquery.min.js'?>"></script>
<?php echo $this->load->view('general/top_scr'); ?>
<?php echo $this->load->view('general/menu'); ?>
<?php echo $konten; ?>
<?php echo $this->load->view('general/footer'); ?>

